"""Run the documented research stages without journal-production dependencies."""
import argparse
from pathlib import Path
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['figures', 'validate', 'all'])
    parser.add_argument('--fresh', action='store_true',
                        help='Recompute the radial grid as part of the all stage.')
    args = parser.parse_args()
    if args.fresh and args.stage != 'all':
        parser.error('--fresh is valid only with the all stage')
    root = Path(__file__).resolve().parent
    steps = []
    if args.stage == 'all':
        steps.append(['compute_results.py'] + (['--fresh'] if args.fresh else []))
    if args.stage in ('validate', 'all'):
        steps += [['verify_results.py'], ['verify_analytic_benchmark.py'],
                  ['verify_model_alignment.py']]
    if args.stage in ('figures', 'all'):
        steps.append(['make_figures.py'])
    for step in steps:
        print('Running ' + ' '.join(step), flush=True)
        subprocess.run([sys.executable, *step], cwd=root, check=True)

if __name__ == '__main__':
    main()
