"""Quantum, phase-insensitive channels and deterministic single-rail recovery.

Quadratures satisfy [q,p]=i. tau is intensity response, N is vacuum-output
occupation. No random classical force or stochastic state sample is used.
"""
from functools import lru_cache
import warnings
import numpy as np
import cvxpy as cp


def coefficients(tau, noise, dim):
    """Exact Fock coefficients of A_(N+1) o L_(tau/(N+1))."""
    if noise < 0 or tau < 0 or tau > 1 + noise + 1e-12:
        raise ValueError('Channel violates complete positivity.')
    n = np.arange(dim)
    gain = 1 + noise
    eta = np.clip(tau/gain, 0, 1)
    ratio = noise/gain
    p0 = ratio**n/gain
    a1 = np.zeros(dim)
    a1[1:] = n[1:]*ratio**(n[1:]-1)/gain**2
    p1 = (1-eta)*p0+eta*a1
    coherence = np.sqrt(eta)*np.sqrt(n[:-1]+1)*ratio**n[:-1]/gain**1.5
    return p0, p1, coherence


def tails(tau, noise, dim):
    """Exact population tails from photon number dim onwards."""
    if dim == 0:
        return 1., 1.
    r = noise/(1+noise)
    eta = tau/(1+noise)
    t0 = r**dim
    t1 = (1-eta)*t0+eta*r**(dim-1)*(dim-(dim-1)*r)
    return float(t0), float(t1)


def cutoff_bound(tau, noise, dim):
    t0, t1 = tails(tau, noise, dim)
    prev0 = tails(tau, noise, dim-1)[0]
    return (t0+t1)/4 + .5*np.sqrt(prev0*t1)


def choose_dim(tau, noise, tolerance=1e-11):
    dim = 2
    while cutoff_bound(tau, noise, dim) > tolerance:
        dim += 1
        if dim > 2000:
            raise RuntimeError('Requested noise needs a larger photon cutoff.')
    return dim


@lru_cache(maxsize=256)
def _programs(dim):
    p0 = cp.Parameter(dim, nonneg=True)
    p1 = cp.Parameter(dim, nonneg=True)
    coherence = cp.Parameter(dim-1, nonneg=True)
    x = cp.Variable(dim)
    z = cp.Variable(dim-1)
    cone = cp.SOC(x[:-1]+1-x[1:],
                  cp.vstack([2*z, x[:-1]-1+x[1:]]), axis=0)
    primal = cp.Problem(cp.Maximize((p0@x+p1@(1-x)+2*coherence@z)/4),
                        [x >= 0, x <= 1, z >= 0, cone])
    lam = cp.Variable(dim)
    a = lam[:-1]-p0[:-1]
    b = lam[1:]-p1[1:]
    dual = cp.Problem(cp.Minimize(cp.sum(lam)/4),
        [lam[0] >= p1[0], lam[-1] >= p0[-1],
         cp.SOC(a+b, cp.vstack([2*coherence, a-b]), axis=0)])
    return p0, p1, coherence, x, lam, primal, dual


def optimal_recovery(tau, noise, dim=None, return_decoder=False):
    """Feasible lower/upper bounds; numerical, NOT interval-arithmetic proofs.

    Covariance reduces the full CPTP recovery SDP exactly to nearest-neighbour
    second-order cones. Clipping x and recomputing its coherences makes the
    lower decoder feasible. Shifting all dual diagonals removes negative
    eigenvalues. The analytic tail bounds the unretained infinite Fock space.
    """
    dim = choose_dim(tau, noise) if dim is None else int(dim)
    p0, p1, c = coefficients(tau, noise, dim)
    pp0, pp1, cc, xvar, lvar, primal, dual = _programs(dim)
    pp0.value, pp1.value, cc.value = p0, p1, c
    options = dict(solver='CLARABEL', tol_gap_abs=1e-11,
                   tol_feas=1e-11, tol_gap_rel=1e-11, max_iter=300)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        primal.solve(**options)
        dual.solve(**options)
    if xvar.value is None or lvar.value is None:
        raise RuntimeError(f'Recovery failed: {primal.status}, {dual.status}')
    x = np.clip(xvar.value, 0, 1)
    z = np.sqrt(x[:-1]*(1-x[1:]))
    lower = (p0@x+p1@(1-x)+2*c@z)/4
    lam = np.array(lvar.value)
    a = lam[:-1]-p0[:-1]
    b = lam[1:]-p1[1:]
    eigmin = min(lam[0]-p1[0], lam[-1]-p0[-1],
                 np.min((a+b-np.hypot(a-b, 2*c))/2))
    # Conservative floating-point guard; not a substitute for directed rounding.
    guard = 128*np.finfo(float).eps*(1+np.max(abs(lam)))
    shift = max(0., -eigmin)+guard
    lam += shift
    finite_upper = np.sum(lam)/4
    tail = cutoff_bound(tau, noise, dim)
    upper = min(1., finite_upper+tail+guard)
    lower = max(0., lower-guard)
    if upper < lower-1e-12:
        raise AssertionError('Primal/dual ordering failed.')
    result = dict(tau=float(tau), N=float(noise), dim=dim,
                  F_lower=float(lower), F_upper=float(upper),
                  gap=float(upper-lower), cutoff_bound=float(tail),
                  dual_shift=float(shift), raw_dual_min_eigenvalue=float(eigmin),
                  primal_status=primal.status, dual_status=dual.status,
                  solver_warnings=len(caught))
    if return_decoder:
        result.update(x=x.tolist(), dual_lambda=lam.tolist())
    return result


def negativity(tau, noise, dim=None):
    """Negativity of the un-decoded Bell-reference/output state, truncated sum."""
    dim = choose_dim(tau, noise, 1e-13)+2 if dim is None else dim
    p0, p1, c = coefficients(tau, noise, dim)
    a, b = p1[:-1], p0[1:]
    return float(np.sum(np.maximum(0, np.hypot(a-b, 2*c)-a-b))/4)


def threshold_decoder_fidelity(tau, noise):
    """CPTP decoder: preserve 0/1 coherence; send all n>=2 to logical |1>."""
    p0, p1, c = coefficients(tau, noise, 2)
    return float((p0[0]+1-p1[0]+2*c[0])/4)


def g_entropy(n):
    n = np.maximum(np.asarray(n, dtype=float), 0)
    out = (n+1)*np.log1p(n)
    positive = n > 0
    out = out - np.where(positive, n*np.log(np.maximum(n, 1e-300)), 0)
    return out


def coherent_information(tau, noise, ns=1.):
    a = ns+.5
    b = tau*ns+noise+.5
    c = np.sqrt(tau*ns*(ns+1))
    root = np.sqrt(max(0., (a+b)**2-4*c*c))
    nu_plus = (root+abs(a-b))/2
    nu_minus = (root-abs(a-b))/2
    return float(g_entropy(b-.5)-g_entropy(nu_plus-.5)-g_entropy(nu_minus-.5))


def full_choi_sdp(tau, noise, dim=8):
    """Independent unrestricted Choi-matrix SDP, no covariance restriction."""
    p0, p1, c = coefficients(tau, noise, dim)
    W = np.diag(np.r_[p0, p1])
    for n in range(dim-1):
        W[n, dim+n+1] = W[dim+n+1, n] = c[n]
    J = cp.Variable((2*dim, 2*dim), hermitian=True)
    problem = cp.Problem(cp.Maximize(cp.real(cp.trace(W@J))/4),
        [J >> 0, J[:dim, :dim]+J[dim:, dim:] == np.eye(dim)])
    problem.solve(solver='CLARABEL', tol_gap_abs=2e-10,
                  tol_feas=2e-10, tol_gap_rel=2e-10, max_iter=300)
    return float(problem.value), float(np.min(np.linalg.eigvalsh(J.value)))
