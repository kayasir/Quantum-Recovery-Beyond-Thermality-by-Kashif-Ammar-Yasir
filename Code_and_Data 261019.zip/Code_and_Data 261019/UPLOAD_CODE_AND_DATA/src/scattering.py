"""Massless scalar Schwarzschild scattering in units G=M=1."""
import numpy as np
from scipy.integrate import solve_ivp

def scattering(omega,ell,order=12,radius_factor=1.,eps=1e-8,rtol=2e-11):
    """Solve the factored ingoing radial ODE; match value and derivative independently."""
    rh=2.; r0=rh*(1+eps); L=ell*(ell+1)
    d0=(L+1)/(rh*(1-2j*omega*rh))
    y0=np.array([1+d0*(r0-rh),d0],complex)
    radius=max(100.,25./omega)*radius_factor
    nodes=np.linspace(radius,1.15*radius,12)
    def rhs(r,y):
        F=1-rh/r; Fp=rh/r**2
        return [y[1],((L/r**2+rh/r**3)*y[0]-(Fp-2j*omega)*y[1])/F]
    sol=solve_ivp(rhs,(r0,nodes[-1]),y0,t_eval=nodes,method='DOP853',
                  rtol=rtol,atol=rtol*.02)
    if not sol.success: raise RuntimeError(sol.message)
    r=nodes; F=1-rh/r; rs=r+rh*np.log(r/rh-1)
    H,Hp=sol.y
    h=np.exp(-1j*omega*rs)*H
    hd=np.exp(-1j*omega*rs)*(F*Hp-1j*omega*H)
    def basis(sign):
        co=[1.+0j]
        for m in range(1,order+1):
            prevprev=co[m-2] if m>=2 else 0
            co.append(((m*(m-1)-L)*co[m-1]-rh*(m-1)**2*prevprev)/(2j*sign*omega*m))
        amp=sum(co[n]*r**(-n) for n in range(order+1))
        amp_p=sum(-n*co[n]*r**(-n-1) for n in range(1,order+1))
        phase=np.exp(1j*sign*omega*rs)
        return phase*amp,phase*(1j*sign*omega*amp+F*amp_p)
    bm,bmd=basis(-1);bp,bpd=basis(1)
    A=np.column_stack([np.r_[bm,bmd/omega],np.r_[bp,bpd/omega]])
    y=np.r_[h,hd/omega]
    ain,aout=np.linalg.lstsq(A,y,rcond=None)[0]
    transmission=1/abs(ain)**2;reflection=abs(aout/ain)**2
    fit=np.linalg.norm(y-A@np.array([ain,aout]))/np.linalg.norm(y)
    current=np.imag(np.conj(h)*hd)/(-omega)
    return dict(omega=float(omega),ell=int(ell),Gamma=float(transmission),
                reflection=float(reflection),flux_error=float(abs(transmission+reflection-1)),
                transmission_real=float((1/ain).real), transmission_imag=float((1/ain).imag),
                fit_error=float(fit),current_error=float(np.max(abs(current-1))))
