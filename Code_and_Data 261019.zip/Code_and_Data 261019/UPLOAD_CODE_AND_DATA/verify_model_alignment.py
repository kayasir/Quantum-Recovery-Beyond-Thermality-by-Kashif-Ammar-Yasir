"""Check operator algebra, covariance spectra and packet conventions independently.

These are numerical cross-checks of the specified stationary field channel,
not an evaporation simulation or a proof using directed-rounding arithmetic.
Run from the release directory: python verify_model_alignment.py
"""
import json
from pathlib import Path
import numpy as np
from scipy.integrate import simpson
from scipy.interpolate import PchipInterpolator
from compute_results import packet_parameters
from src.channels import coefficients, coherent_information, g_entropy

ROOT = Path(__file__).resolve().parent


def main():
    checks = []

    def check(name, error, tolerance):
        error = float(error)
        checks.append(dict(test=name, error=error, tolerance=tolerance,
                           passed=bool(np.isfinite(error) and error <= tolerance)))

    # Independently assemble all three physical output modes, not just R.
    # y = U x + V x^dagger, x=(b,c,e), y=(R,C,L).
    canonical, anomalous = [], []
    for gain in [1., 1.01, 1.5, 3., 10.]:
        for gamma in [0., .03, .5, .91, 1.]:
            U = np.array([[np.sqrt(gamma*gain), 0, np.sqrt(1-gamma)],
                          [0, np.sqrt(gain), 0],
                          [-np.sqrt((1-gamma)*gain), 0, np.sqrt(gamma)]])
            V = np.array([[0, np.sqrt(gamma*(gain-1)), 0],
                          [np.sqrt(gain-1), 0, 0],
                          [0, -np.sqrt((1-gamma)*(gain-1)), 0]])
            canonical.append(np.max(abs(U@U.T-V@V.T-np.eye(3))))
            anomalous.append(np.max(abs(U@V.T-V@U.T)))
    check('three-mode canonical commutators, 25 dilations', max(canonical), 2e-14)
    check('three-mode anomalous commutators, 25 dilations', max(anomalous), 2e-14)

    # Obtain symplectic eigenvalues by matrix diagonalization rather than the
    # closed formula used by coherent_information().
    omega2 = np.array([[0., 1.], [-1., 0.]])
    omega4 = np.kron(np.eye(2), omega2)
    symplectic_errors, information_errors, population_errors = [], [], []
    parameters = [(0., 0.), (.12, 0.), (1., 0.), (0., .5),
                  (.02, .1), (.6, .5), (1.1, .1), (2., 1.)]
    for tau, noise in parameters:
        ns = 1.
        a, b = ns+.5, tau*ns+noise+.5
        c = np.sqrt(tau*ns*(ns+1))
        covariance = np.block([[a*np.eye(2), c*np.diag([1., -1.])],
                               [c*np.diag([1., -1.]), b*np.eye(2)]])
        eigenvalues = np.sort(abs(np.linalg.eigvals(1j*omega4@covariance)))
        nus = eigenvalues[::2]
        root = np.sqrt((a+b)**2-4*c*c)
        closed = np.array([(root-abs(a-b))/2, (root+abs(a-b))/2])
        symplectic_errors.append(np.max(abs(nus-closed)))
        direct = float(g_entropy(b-.5)-sum(g_entropy(nu-.5) for nu in nus))
        information_errors.append(abs(direct-coherent_information(tau, noise, ns)))
        p0, p1, _ = coefficients(tau, noise, 240)
        n = np.arange(len(p0))
        population_errors.extend([abs(p0.sum()-1), abs(p1.sum()-1),
                                  abs(n@p0-noise), abs(n@p1-(noise+tau))])
    check('symplectic spectrum from i Omega V, 8 channels', max(symplectic_errors), 2e-13)
    check('coherent information from diagonalized covariance, 8 channels',
          max(information_errors), 2e-12)
    check('Fock normalization and output occupations, 8 channels',
          max(population_errors), 2e-13)

    radial = np.genfromtxt(ROOT/'data/radial_data.csv', delimiter=',', names=True)
    physical = np.genfromtxt(ROOT/'data/schwarzschild_recovery.csv', delimiter=',', names=True)
    check('radial grid: ell=0,1,2 and 239 frequencies per ell',
          max(abs(len(radial)-717),
              *(np.max(abs(radial['omega'][radial['ell']==ell]-np.linspace(.005,.6,239)))
                for ell in range(3))), 2e-15)
    gain = 1/(-np.expm1(-8*np.pi*physical['omega']))
    check('all 717 gains use dimensionless w and Hawking temperature',
          np.max(abs(physical['gain']-gain)), 2e-14)
    check('all 717 physical channels: tau=Gamma G and N=Gamma(G-1)',
          max(np.max(abs(physical['tau']-physical['Gamma']*gain)),
              np.max(abs(physical['N']-physical['Gamma']*(gain-1)))), 2e-14)
    check('radial complex transmission modulus equals Gamma',
          np.max(abs(radial['transmission_real']**2+
                     radial['transmission_imag']**2-radial['Gamma'])), 2e-14)

    # Full complex amplitude integral with a nonconstant test phase. The phase
    # is deliberately arbitrary: a calibrated g0 must cancel it for ANY phase.
    w = np.linspace(.005, .6, 8001)
    select = radial['ell']==0
    gamma = PchipInterpolator(radial['omega'][select], radial['Gamma'][select])(w)
    gain = 1/(-np.expm1(-8*np.pi*w))
    transmission = np.sqrt(gamma)*np.exp(1j*(.7+13*w+41*w*w))
    delays = np.array([0., 1., 10., 40., 80., 160.])
    normalization_errors, amplitude_errors, noise_errors, commutator_errors = [], [], [], []
    for sigma in [.015, .035, .055]:
        tau, noise, _, _ = packet_parameters(w, gamma, .16, sigma, delays)
        f = np.exp(-.25*((w-.16)/sigma)**2)
        f /= np.sqrt(simpson(abs(f)**2, x=w))
        u = transmission*np.sqrt(gain)*f
        g0 = u/np.sqrt(simpson(abs(u)**2, x=w))
        normalization_errors.extend([abs(simpson(abs(f)**2,x=w)-1),
                                     abs(simpson(abs(g0)**2,x=w)-1)])
        for index, delay in enumerate(delays):
            g = g0*np.exp(-1j*w*delay)
            alpha = simpson(g.conj()*transmission*np.sqrt(gain)*f, x=w)
            direct_noise = simpson(abs(g)**2*gamma*(gain-1), x=w)
            amplitude_errors.append(abs(abs(alpha)**2-tau[index]))
            noise_errors.append(abs(direct_noise-noise))
            # Unencoded input modes and barrier vacuum give zeta zeta^dagger;
            # partner creation gives zeta^dagger zeta. Both are quantum terms.
            input_vacuum = simpson(abs(g)**2*gamma*gain,x=w)-abs(alpha)**2
            barrier_vacuum = simpson(abs(g)**2*(1-gamma),x=w)
            commutator_errors.append(abs(input_vacuum+barrier_vacuum-direct_noise
                                          -(1-abs(alpha)**2)))
    check('input and receiver packet normalization, 3 widths', max(normalization_errors), 2e-14)
    check('complex packet amplitudes versus reduced Fourier formula, 18 cases',
          max(amplitude_errors), 2e-13)
    check('complex packet vacuum occupation and delay invariance, 18 cases',
          max(noise_errors), 2e-14)
    check('packet quantum-noise commutator including orthogonal modes, 18 cases',
          max(commutator_errors), 2e-13)

    packets = np.genfromtxt(ROOT/'data/packet_recovery.csv', delimiter=',', names=True)
    errors = []
    for sigma in [.015, .035, .055]:
        rows = packets[packets['sigma']==sigma]
        tau, noise, _, _ = packet_parameters(w, gamma, .16, sigma, rows['delay'])
        errors.extend([np.max(abs(rows['tau']-tau)), np.max(abs(rows['N']-noise)),
                       np.max(abs(rows['center']-.16)),
                       np.max(abs(rows['delay']-np.linspace(0,160,161)))])
    check('all 483 packet rows match stated centers, widths, delays and integrals',
          max(errors), 2e-13)

    report = dict(total_checks=len(checks), passed=sum(c['passed'] for c in checks),
                  failed=sum(not c['passed'] for c in checks), checks=checks)
    (ROOT/'validation').mkdir(exist_ok=True)
    (ROOT/'validation/model_alignment_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
    if report['failed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
