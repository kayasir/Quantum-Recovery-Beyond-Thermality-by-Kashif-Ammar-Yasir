"""Reproduce source data. Run from this directory: python compute_results.py.

An existing radial_data.csv is reused unless --fresh is supplied. All other
data are recomputed. Typical runtime is several minutes on a CPU.
"""
import argparse
import csv
import json
from pathlib import Path
import sys
import time
import numpy as np
from scipy.integrate import simpson
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from src.channels import (optimal_recovery, negativity,
    threshold_decoder_fidelity, coherent_information)
from src.scattering import scattering

ROOT = Path(__file__).resolve().parent
DATA = ROOT/'data'
DATA.mkdir(exist_ok=True)


def write_rows(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_rows(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def scalar_metrics(tau, noise):
    ans = optimal_recovery(tau, noise)
    ans['negativity'] = negativity(tau, noise)
    ans['F_threshold'] = threshold_decoder_fidelity(tau, noise)
    return ans


def packet_parameters(w, gamma, center, sigma, delays):
    """f has Gaussian intensity, normalized on the explicitly retained band.

    g_0 = t sqrt(G) f / ||t sqrt(G)f||; g_delay=g_0 exp(-i*w*delay).
    Known scattering phase is compensated by this specified receiver.
    """
    f2 = np.exp(-.5*((w-center)/sigma)**2)
    f2 /= simpson(f2, x=w)
    gain = 1/(-np.expm1(-8*np.pi*w))
    density = f2*gamma*gain
    tau0 = simpson(density, x=w)
    density /= tau0
    noise = simpson(density*gamma*(gain-1), x=w)
    characteristic = simpson(density[:, None]*np.exp(1j*w[:, None]*np.asarray(delays)), x=w, axis=0)
    tau = tau0*abs(characteristic)**2
    return tau, float(noise), density, f2


def main(fresh=False):
    start = time.time()
    radial_path = DATA/'radial_data.csv'
    if fresh or not radial_path.exists():
        radial = []
        wgrid = np.linspace(.005, .6, 239)
        for ell in range(3):
            for i, w in enumerate(wgrid):
                radial.append(scattering(w, ell))
                if i % 60 == 0:
                    print(f'radial ell={ell}, {i+1}/{len(wgrid)}', flush=True)
        write_rows(radial_path, radial)
    else:
        radial = [{k:float(v) for k,v in row.items()} for row in load_rows(radial_path)]
    physical = []
    for row in radial:
        w, gamma = row['omega'], row['Gamma']
        gain = 1/(-np.expm1(-8*np.pi*w))
        noise, tau = gamma*(gain-1), gamma*gain
        metrics = scalar_metrics(tau, noise)
        metrics.update(omega=w, ell=int(row['ell']), Gamma=gamma, gain=gain,
            Ic_nats=coherent_information(tau, noise),
            partial_energy_spectrum=(2*int(row['ell'])+1)*w*noise/(2*np.pi))
        physical.append(metrics)
    write_rows(DATA/'schwarzschild_recovery.csv', physical)
    print('frequency-resolved recovery complete', flush=True)

    frontier=[]
    for noise in np.linspace(0, .8, 49):
        for tau in np.linspace(0, 1.8, 73):
            if tau <= 1+noise+1e-13:
                frontier.append(scalar_metrics(tau, noise))
    write_rows(DATA/'recovery_frontier.csv', frontier)
    iso=[]
    for noise in [.03, .1, .5, 1.]:
        for gamma in np.linspace(.001,1,101):
            row=scalar_metrics(noise+gamma,noise)
            row['Gamma']=gamma
            iso.append(row)
    write_rows(DATA/'equal_noise_recovery.csv',iso)
    decoder_examples=[]
    for tau,noise in [(.12,.1),(1.1,.1),(.6,.5),(1.5,.5),(2.,1.)]:
        decoder_examples.append(optimal_recovery(tau,noise,return_decoder=True))
    (DATA/'optimal_decoders.json').write_text(json.dumps(decoder_examples,indent=2))
    print('recovery parameter maps complete', flush=True)

    ell0=[r for r in radial if int(r['ell'])==0]
    wg=np.array([r['omega'] for r in ell0]); gg=np.array([r['Gamma'] for r in ell0])
    interpolator=PchipInterpolator(wg,gg)
    finew=np.linspace(wg[0],wg[-1],8001)
    finegamma=interpolator(finew)
    delays=np.linspace(0,160,161)
    packets=[]
    spectra=[]
    for sigma in [.015,.035,.055]:
        tau,N,density,f2=packet_parameters(finew,finegamma,.16,sigma,delays)
        for delay,t in zip(delays,tau):
            row=scalar_metrics(float(t),N)
            row.update(center=.16,sigma=sigma,delay=delay)
            packets.append(row)
        for j in range(0,len(finew),20):
            spectra.append(dict(omega=finew[j],sigma=sigma,
                                input_density=f2[j],receiver_density=density[j]))
    write_rows(DATA/'packet_recovery.csv',packets)
    write_rows(DATA/'packet_spectra.csv',spectra)
    phase_map=[]
    for sigma in np.linspace(.01,.065,57):
        tau,N,_,_=packet_parameters(finew,finegamma,.16,sigma,delays)
        for delay,t in zip(delays,tau):
            phase_map.append(dict(sigma=sigma,delay=delay,tau=float(t),N=N,
                                  log10_signal_noise=float(np.log10(max(t/N,1e-20)))))
    write_rows(DATA/'packet_access_map.csv',phase_map)

    # Root finding here uses new ODE solves, not crossing read-offs from a plot.
    thresholds=[]
    for ell in range(3):
        def channel(w):
            gam=scattering(w,ell)['Gamma']
            ga=1/(-np.expm1(-8*np.pi*w))
            return gam,gam*ga,gam*(ga-1)
        def eval_kind(w,kind):
            gam,t,N=channel(w)
            if kind=='Gamma_half': return gam-.5
            if kind=='Ic_zero_ns1': return coherent_information(t,N)
            target=.5 if kind=='F_half' else .9
            return optimal_recovery(t,N)['F_lower']-target
        for kind in ['F_half','Gamma_half','Ic_zero_ns1','F_nine_tenths']:
            if eval_kind(.005,kind)*eval_kind(.6,kind)<0:
                root=brentq(lambda w:eval_kind(w,kind),.005,.6,xtol=2e-10)
                gam,t,N=channel(root)
                thresholds.append(dict(ell=ell,threshold=kind,omega=root,
                                       Gamma=gam,tau=t,N=N))
    write_rows(DATA/'frequency_thresholds.csv',thresholds)

    all_solves=physical+frontier+iso+packets+decoder_examples
    stats=dict(radial_points=len(radial),recovery_points=len(all_solves),
        max_recovery_gap=max(r['gap'] for r in all_solves),
        max_cutoff_bound=max(r['cutoff_bound'] for r in all_solves),
        max_dimension=max(r['dim'] for r in all_solves),
        solver_warning_count=sum(r['solver_warnings'] for r in all_solves),
        max_radial_flux_error=max(r['flux_error'] for r in radial),
        max_radial_match_error=max(r['fit_error'] for r in radial),
        runtime_seconds=time.time()-start)
    (DATA/'computation_summary.json').write_text(json.dumps(stats,indent=2))
    print(json.dumps(stats,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--fresh',action='store_true')
    main(parser.parse_args().fresh)
