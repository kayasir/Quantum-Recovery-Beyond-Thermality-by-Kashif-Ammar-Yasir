"""Independent mathematical, numerical, and physical consistency checks.

Writes an auditable JSON report and exits nonzero on a failed tolerance.
These checks do not constitute peer review or a formal proof of code correctness.
"""
import csv
import json
import platform
from pathlib import Path
import numpy as np
import scipy
import cvxpy
import sympy as sp
from scipy.integrate import simpson
from scipy.interpolate import PchipInterpolator
from scipy.special import gammaln
from src.channels import (coefficients, optimal_recovery, full_choi_sdp,
    cutoff_bound, tails, negativity, threshold_decoder_fidelity)
from src.scattering import scattering
from compute_results import packet_parameters

ROOT=Path(__file__).resolve().parent
records=[]


def check(name,error,tolerance,**extra):
    error=float(error)
    record=dict(test=name,error=error,tolerance=float(tolerance),
                passed=bool(np.isfinite(error) and error<=tolerance),**extra)
    records.append(record)
    if not record['passed']:
        print('FAILED',record,flush=True)


def rows(name):
    with (ROOT/'data'/name).open() as f:
        return list(csv.DictReader(f))


def kraus_coefficients(gamma,gain,dim=12,kmax=250):
    """Independent original order: amplifier followed by beam splitter."""
    out0=np.zeros(dim);out1=np.zeros(dim);coh=np.zeros(dim-1)
    def choose(n,k):
        return np.exp(gammaln(n+1)-gammaln(k+1)-gammaln(n-k+1))
    for k in range(kmax):
        a0=np.sqrt((gain-1)**k/gain**(k+1))
        a1=np.sqrt((k+1)*(gain-1)**k/gain**(k+2))
        for q in range(min(k+1,dim)):
            j=k-q
            l0=np.sqrt(choose(k,j)*gamma**q*(1-gamma)**j)
            out0[q]+=(a0*l0)**2
            if q<dim-1:
                l1=np.sqrt(choose(k+1,j)*gamma**(q+1)*(1-gamma)**j)
                coh[q]+=a0*a1*l0*l1
        for q in range(min(k+2,dim)):
            j=k+1-q
            l1=np.sqrt(choose(k+1,j)*gamma**q*(1-gamma)**j)
            out1[q]+=(a1*l1)**2
    return out0,out1,coh


def main():
    # Symbolic partial-transpose determinant, derived independently of plotting.
    t,N=sp.symbols('t N',positive=True)
    p10=(N+1-t)/(N+1)**2
    p01=N/(N+1)**2
    c0sq=t/(N+1)**4
    check('symbolic NPT determinant',int(sp.simplify(p10*p01-c0sq-(N-t)/(N+1)**3)!=0),0)

    for tau in [0.,.01,.2,.5,.9,1.]:
        r=optimal_recovery(tau,0)
        exact=(1+np.sqrt(tau))**2/4
        check(f'pure-loss exact fidelity tau={tau}',abs(r['F_lower']-exact),2e-8)
        check(f'pure-loss negativity tau={tau}',abs(negativity(tau,0)-tau/2),1e-13)
    for noise in [.01,.1,1.]:
        r=optimal_recovery(0,noise)
        check(f'constant channel fidelity N={noise}',abs(r['F_lower']-.25),2e-8)
    for gamma,gain in [(.02,1.1),(.2,2.),(.6,1.4),(.9,3.),(1.,1.2)]:
        tau,N=gamma*gain,gamma*(gain-1)
        direct=kraus_coefficients(gamma,gain)
        closed=coefficients(tau,N,12)
        check(f'Kraus vs reordered-channel coefficients {gamma},{gain}',
              max(np.max(abs(a-b)) for a,b in zip(direct,closed)),2e-12)
    for tau,N in [(.08,.1),(.1,.1),(.11,.1),(.8,.1),(1.1,.1),(.6,.5),(1.5,.5)]:
        dim=8
        reduced=optimal_recovery(tau,N,dim)
        full,mineig=full_choi_sdp(tau,N,dim)
        check(f'unrestricted complex SDP vs reduced cones {tau},{N}',
              abs(full-reduced['F_lower']),2e-7,full_sdp_min_eigenvalue=mineig)
        check(f'NPT criterion {tau},{N}',float((negativity(tau,N)>1e-12)!=(tau>N)),0)

    # Independent finite Choi construction, physical decoder, and six-state average.
    tau,N=.6,.5
    D=12
    r=optimal_recovery(tau,N,D,return_decoder=True)
    x=np.array(r['x']);p0,p1,c=coefficients(tau,N,D)
    dec=[]
    for n in range(D-1):
        K=np.zeros((2,D));K[0,n]=np.sqrt(x[n]);K[1,n+1]=np.sqrt(1-x[n+1]);dec.append(K)
    K=np.zeros((2,D));K[1,0]=np.sqrt(1-x[0]);dec.append(K)
    K=np.zeros((2,D));K[0,-1]=np.sqrt(x[-1]);dec.append(K)
    check('explicit decoder trace preservation',np.max(abs(sum(K.T@K for K in dec)-np.eye(D))),1e-14)
    code_states=[np.array([1,0]),np.array([0,1])]
    code_states += [np.array([1,s])/np.sqrt(2) for s in [1,-1,1j,-1j]]
    averages=[]
    t0,t1=tails(tau,N,D)
    for psi in code_states:
        rho=np.outer(psi,psi.conj())
        oscillator=rho[0,0]*np.diag(p0)+rho[1,1]*np.diag(p1)
        oscillator=oscillator+rho[0,1]*np.diag(c,1)+rho[1,0]*np.diag(c,-1)
        output=sum(K@oscillator@K.T for K in dec)
        output[1,1]+=rho[0,0]*t0+rho[1,1]*t1  # CPTP flagged-tail extension
        averages.append(float(np.real(psi.conj()@output@psi)))
    retained_f=(p0@x+p1@(1-x)+2*c@np.sqrt(x[:-1]*(1-x[1:])))/4
    check('six-state Haar average vs entanglement fidelity',
          abs(np.mean(averages)-(2*(retained_f+t1/4)+1)/3),1e-13)

    convergence=[]
    fine=optimal_recovery(1.2,1.,dim=90)
    for D in [4,6,8,12,16,24,32,48,64]:
        r=optimal_recovery(1.2,1.,dim=D)
        check(f'cutoff interval contains converged result D={D}',
              max(0,r['F_lower']-fine['F_upper'],fine['F_lower']-r['F_upper']),2e-9)
        convergence.append(r)
    (ROOT/'validation'/'cutoff_convergence.json').write_text(json.dumps(convergence,indent=2))

    radial=rows('radial_data.csv')
    for row in radial:
        check(f'flux ell={row["ell"]},w={row["omega"]}',float(row['flux_error']),2e-8)
    for ell,w in [(0,.005),(0,.08),(0,.125),(0,.3),(1,.1),(1,.3),(2,.2),(2,.48)]:
        base=scattering(w,ell)
        ref=scattering(w,ell,order=14,radius_factor=1.4,eps=3e-9,rtol=5e-12)
        check(f'radial refinement ell={ell},w={w}',
              abs(base['Gamma']-ref['Gamma'])/max(ref['Gamma'],1e-30),2e-7)
    # Leading low-frequency prediction is asymptotic, not an exact finite-w value.
    loww=[.0005,.001,.002]
    ratios=[scattering(w,0)['Gamma']/(16*w*w) for w in loww]
    check('s-wave low-frequency asymptote improves towards zero',
          float(not (abs(ratios[0]-1)<abs(ratios[1]-1)<abs(ratios[2]-1))),0,
          omega=loww,ratio=ratios)

    for name in ['schwarzschild_recovery.csv','recovery_frontier.csv',
                 'equal_noise_recovery.csv','packet_recovery.csv']:
        data=rows(name)
        check(f'finite recovery interval width {name}',max(float(r['gap']) for r in data),1e-6)
        check(f'complete positivity {name}',max(0.,max(float(r['tau'])-1-float(r['N']) for r in data)),1e-12)
        check(f'optimal recovery dominates explicit decoder {name}',
              max(0.,max(float(r['F_threshold'])-float(r['F_upper']) for r in data)),2e-10)
        check(f'EB channels obey measure/prepare bound {name}',
              max([0.]+[float(r['F_lower'])-.5 for r in data if float(r['tau'])<=float(r['N'])]),1e-10)

    ell0=[r for r in radial if int(float(r['ell']))==0]
    wg=np.array([float(r['omega']) for r in ell0]);gg=np.array([float(r['Gamma']) for r in ell0])
    interp=PchipInterpolator(wg,gg)
    basew=np.linspace(wg[0],wg[-1],8001)
    finew=np.linspace(wg[0],wg[-1],16001)
    delays=np.arange(0,161,10)
    # Resolve interpolation error with an independently calculated half-step grid.
    midw=(wg[1:]+wg[:-1])/2
    midgamma=np.array([scattering(w,0)['Gamma'] for w in midw])
    bothw=np.r_[wg,midw];bothg=np.r_[gg,midgamma];order=np.argsort(bothw)
    refined=PchipInterpolator(bothw[order],bothg[order])
    refinements=[]
    for sigma in [.015,.035,.055]:
        bt,bN,_,_=packet_parameters(basew,interp(basew),.16,sigma,delays)
        qt,qN,_,_=packet_parameters(finew,interp(finew),.16,sigma,delays)
        rt,rN,_,_=packet_parameters(finew,refined(finew),.16,sigma,delays)
        check(f'packet quadrature convergence sigma={sigma}',max(np.max(abs(bt-qt)),abs(bN-qN)),1e-8)
        check(f'packet scattering-grid refinement sigma={sigma}',max(np.max(abs(bt-rt)),abs(bN-rN)),2e-6)
        for delay,t1,t2 in zip(delays,bt,rt):
            f1=optimal_recovery(t1,bN)['F_lower'];f2=optimal_recovery(t2,rN)['F_lower']
            refinements.append(dict(sigma=sigma,delay=float(delay),F_base=f1,F_refined=f2,
                                    absolute_difference=abs(f1-f2)))
    check('packet fidelity under scattering-grid refinement',max(r['absolute_difference'] for r in refinements),3e-6)
    (ROOT/'validation'/'packet_refinement.json').write_text(json.dumps(refinements,indent=2))
    report=dict(total_checks=len(records),passed=sum(r['passed'] for r in records),
        failed=sum(not r['passed'] for r in records),
        environment=dict(python=platform.python_version(),numpy=np.__version__,
                         scipy=scipy.__version__,cvxpy=cvxpy.__version__),checks=records)
    (ROOT/'validation'/'verification_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2),flush=True)
    if report['failed']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
