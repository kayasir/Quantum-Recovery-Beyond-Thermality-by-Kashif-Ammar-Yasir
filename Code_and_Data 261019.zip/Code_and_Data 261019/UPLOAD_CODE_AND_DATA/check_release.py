"""Check the downloaded release against its recorded SHA-256 file hashes."""
import hashlib
from pathlib import Path

def main():
    root = Path(__file__).resolve().parent
    failed = []
    count = 0
    for line in (root/'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = root/name
        count += 1
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            failed.append(name)
    print(f'{count-len(failed)}/{count} files match the release manifest.')
    for name in failed:
        print('CHANGED OR MISSING: ' + name)
    if failed:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
