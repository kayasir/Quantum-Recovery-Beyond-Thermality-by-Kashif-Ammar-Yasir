CODE AND DATA
Operational limits of quantum recovery from black-hole radiation
Release 1.0.0, prepared 19 October 2026
Research contact: Kashif Ammar Yasir, kayasir@zjnu.edu.cn

PURPOSE
This release contains the Python implementation, numerical data, figures and
validation records for the specified stationary Schwarzschild field-channel
calculation. The task is deterministic recovery of a vacuum/one-particle qubit.
The model is not a microscopic evaporation theory. See the accompanying article
and independent supplementary derivations for assumptions and interpretation.

START HERE (WINDOWS 10/11)
1. Extract the ZIP completely. Open its UPLOAD_CODE_AND_DATA folder.
2. Install Python 3.12 if it is not available. Open Command Prompt in this folder.
3. Run the following lines one at a time:
   py -3.12 -m venv .venv
   .venv\Scripts\python.exe -m pip install --upgrade pip
   .venv\Scripts\python.exe -m pip install -r requirements.txt
   .venv\Scripts\python.exe check_release.py
4. To redraw figures from the included data:
   .venv\Scripts\python.exe reproduce.py figures
5. To rerun the independent verification:
   .venv\Scripts\python.exe reproduce.py validate
6. To recompute the data, verification and figures, including the radial grid:
   .venv\Scripts\python.exe reproduce.py all --fresh

MACOS / LINUX
   python3.12 -m venv .venv
   .venv/bin/python -m pip install --upgrade pip
   .venv/bin/python -m pip install -r requirements.txt
   .venv/bin/python check_release.py
   .venv/bin/python reproduce.py figures
   .venv/bin/python reproduce.py validate
   .venv/bin/python reproduce.py all --fresh

Choose the stage you need. Full reproduction uses a CPU; no GPU, Mathematica,
TeX installation or network service is required after dependencies are installed.
The archived full calculation was executed under Python 3.12 on Linux; this
release does not claim a separate Windows or macOS execution test. Allow several
minutes or longer for all, depending on the machine and conic solver. Keep an
unchanged downloaded copy: computation and verification replace data/reports,
and figure generation replaces artwork. Check hashes BEFORE rerunning stages.

For figure drawing alone, install requirements-figures.txt instead of the full
requirements.txt; no convex-optimization package is then needed. For exact
archived typography install Liberation Sans. The fallback is DejaVu Sans.
You can place LiberationSans-*.ttf in a fonts folder here or point the environment
variable BH_RECOVERY_FONT_DIR to an existing folder of these fonts. Numerical
values are independent of font availability. PDF/EPS exports embed their fonts.

CONTENTS
src/channels.py: quantum-channel coefficients and deterministic recovery solvers.
src/scattering.py: Schwarzschild scalar radial solver and matching diagnostics.
compute_results.py: all numerical grids, packet collection and threshold roots.
verify_results.py: independent Kraus/Choi, limits and refinement checks.
verify_analytic_benchmark.py: symbolic and numerical comparator checks.
verify_model_alignment.py: operator, covariance, packet and parameter checks.
MODEL_CODE_AUDIT.txt: equation-to-code mapping and all numerical settings.
make_figures.py: four main composite figures, FigS1 and standalone schematic.
reproduce.py: portable entry point for the three stages.
data/: eight CSV tables and two JSON files; see DATA_DICTIONARY.txt.
figures/: archived EPS/PDF/PNG artwork and the schematic SVG.
validation/: numerical verification, convergence and environment records.
SOURCE_DATA_MAP.txt: connects each panel with its input file or analytic formula.
CITATION.txt: citation details; use this repository release URL and version.
LICENSES.txt: license scopes; read before reusing the release.
SHA256SUMS and check_release.py: download integrity checks, not physics tests.

INTERPRETING VALIDATION
A full fresh calculation on 19 October 2026 reproduced all eight CSV tables
exactly in the pinned environment. The core report records 795 passing checks;
the analytic report records 15 and the model-alignment report records 14.
Fresh-run records are in validation/recheck_20261019/. All checks passed.
Reported intervals combine numerical primal/dual estimates with analytic Fock-
tail control; they are not statistical confidence intervals or directed-rounding
certificates. Raw solver statuses and warnings are retained. An
optimal_inaccurate status must be interpreted with the reported feasibility
corrections, gap and independent checks rather than silently discarded.

NUMERICAL CONVENTIONS
c=hbar=k_B=1; dimensionless w=GM*omega; code evaluates G=M=1.
The column named omega contains w, not a frequency in hertz. tau, N, Gamma,
fidelities and occupations are dimensionless. delay=Delta_t/(GM).
Quadratures obey [q,p]=i with vacuum covariance I/2. Coherent information is
stored in nats and divided by ln(2) for the bit-valued plot. No experimental
samples or classical random-noise realizations are present in these datasets.
