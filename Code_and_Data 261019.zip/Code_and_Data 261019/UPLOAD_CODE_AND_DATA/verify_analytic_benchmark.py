"""Verify the added analytic comparator and data-backed interpretive claims.

The core solver and radial data are unchanged. This script tests the new
closed expression independently, then audits its use in every archived map.
"""
import csv
import json
from pathlib import Path
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parent
records=[]
def check(name,error,tolerance,**details):
    error=float(error)
    records.append(dict(test=name,error=error,tolerance=float(tolerance),
                        passed=bool(np.isfinite(error) and error<=tolerance),**details))

def main():
    y,N=sp.symbols('y N',nonnegative=True)
    p00=1/(1+N)
    p10=(1+N-y*y)/(1+N)**2
    c0=y/(1+N)**2
    closed=(1+(y*y+2*y)/(1+N)**2)/4
    check('symbolic comparator from exact channel coefficients',
          int(sp.simplify((p00+1-p10+2*c0)/4-closed)!=0),0)
    check('symbolic pure-loss limit',
          int(sp.simplify(closed.subs(N,0)-(1+y)**2/4)!=0),0)
    root=sp.sqrt(1+(1+N)**2)-1
    check('symbolic classical crossing for explicit decoder',
          int(sp.simplify(root**2+2*root-(1+N)**2)!=0),0)
    summaries={}
    for name in ['recovery_frontier.csv','schwarzschild_recovery.csv',
                 'equal_noise_recovery.csv','packet_recovery.csv']:
        with (ROOT/'data'/name).open() as f:rows=list(csv.DictReader(f))
        t=np.array([float(r['tau']) for r in rows])
        n=np.array([float(r['N']) for r in rows])
        lo=np.array([float(r['F_lower']) for r in rows])
        hi=np.array([float(r['F_upper']) for r in rows])
        th=np.array([float(r['F_threshold']) for r in rows])
        analytic=(1+(t+2*np.sqrt(t))/(1+n)**2)/4
        check('closed expression vs archived comparator: '+name,
              np.max(abs(analytic-th)),1e-14,points=len(rows))
        check('achievable comparator below numerical upper: '+name,
              max(0.,np.max(analytic-hi)),1e-10)
        delta=lo-analytic;j=int(np.argmax(delta))
        summaries[name]=dict(points=len(rows),max_gain=float(delta[j]),
            tau=float(t[j]),N=float(n[j]),
            min_gain=float(np.min(delta)),max_interval=float(np.max(hi-lo)))
    check('stated Schwarzschild-grid maximum gain rounded to 0.0001472871',
          abs(summaries['schwarzschild_recovery.csv']['max_gain']-.0001472871),1e-10)
    check('stated general-grid maximum gain rounded to 0.06228180',
          abs(summaries['recovery_frontier.csv']['max_gain']-.06228180),5e-9)
    # Direct values distinguish a selected-mode channel from its unchanged vacuum state.
    with (ROOT/'data'/'packet_recovery.csv').open() as f:rows=list(csv.DictReader(f))
    r=[v for v in rows if np.isclose(float(v['sigma']),.035)
       and float(v['delay']) in (0.,80.)]
    r.sort(key=lambda v:float(v['delay']))
    check('fixed thermal occupation in quoted packet comparison',
          abs(float(r[0]['N'])-float(r[1]['N'])),1e-15)
    check('quoted packet crosses exact entanglement-breaking boundary',
          int(not (float(r[0]['tau'])>float(r[0]['N']) and
                   float(r[1]['tau'])<float(r[1]['N']))),0)
    report=dict(total_checks=len(records),passed=sum(r['passed'] for r in records),
                failed=sum(not r['passed'] for r in records),
                grid_summaries=summaries,checks=records)
    (ROOT/'validation'/'analytic_benchmark_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:report[k] for k in ['total_checks','passed','failed']},indent=2))
    if report['failed']:raise SystemExit(1)

if __name__=='__main__':main()

