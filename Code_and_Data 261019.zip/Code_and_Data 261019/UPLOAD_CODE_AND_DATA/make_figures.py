"""Four main and one supplementary data-driven composite figures; editable vector EPS/PDF.

All curves use archived source data. No interpolation is used to fabricate
samples; contour interpolation is solely the stated display interpolation.
"""
import csv
import io
import json
import os
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

ROOT=Path(__file__).resolve().parent
FIG=ROOT/'figures'
FIG.mkdir(exist_ok=True)
C=['#0072B2','#D55E00','#009E73','#CC79A7']
INK='#202C39';GREY='#718096'
# Liberation Sans is metrically compatible with Arial. Use a portable fallback
# when it is absent; vector exports embed the fonts used for this release.
for fontdir in [ROOT/'fonts', Path('/usr/share/fonts/truetype/liberation2'),
                Path('/usr/share/fonts/truetype/liberation'),
                Path(os.environ.get('BH_RECOVERY_FONT_DIR', str(ROOT/'fonts')))]:
    if fontdir.exists():
        for fontfile in fontdir.glob('LiberationSans-*.ttf'):
            font_manager.fontManager.addfont(str(fontfile))
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Liberation Sans','DejaVu Sans'],
    'mathtext.fontset':'dejavusans','font.size':8,'axes.labelsize':8,'axes.titlesize':8.5,
    'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
    'axes.spines.top':True,'axes.spines.right':True,
    'axes.linewidth':.85,'lines.linewidth':1.7,'xtick.major.width':.8,
    'ytick.major.width':.8,'xtick.direction':'in','ytick.direction':'in',
    'xtick.top':True,'ytick.right':True,'xtick.major.pad':4,'ytick.major.pad':4,
    'pdf.fonttype':42,'ps.fonttype':42,
    'savefig.dpi':400,'text.color':INK,'axes.labelcolor':INK,
    'axes.edgecolor':INK,'xtick.color':INK,'ytick.color':INK})


def data(name):
    with (ROOT/'data'/name).open() as f:
        rows=list(csv.DictReader(f))
    out={}
    for key in rows[0]:
        try:out[key]=np.array([float(r[key]) for r in rows])
        except ValueError:pass
    return out


def panel(ax,letter,title):
    ax.text(-.16,1.07,letter,transform=ax.transAxes,fontweight='bold',fontsize=11,
            ha='left',va='bottom')
    ax.set_title(title,loc='left',pad=9)


def legend(ax,**kwargs):
    return ax.legend(frameon=True,framealpha=1,facecolor='white',edgecolor='#E1E5EA',
                     borderpad=.35,handlelength=1.7,**kwargs)


def save(fig,name,bbox=None,close=True,svg=False):
    # Fixed canvas guarantees consistent 180-mm artwork, without a tight-box resize.
    for ext in ['pdf','eps','png']+(['svg'] if svg else []):
        buffer=io.BytesIO()
        fig.savefig(buffer,format=ext,facecolor='white',bbox_inches=bbox)
        payload=buffer.getvalue()
        if len(payload)<100:
            raise RuntimeError(f'Empty or incomplete {ext} export for {name}')
        destination=FIG/f'{name}.{ext}'
        temporary=destination.with_suffix('.'+ext+'.tmp')
        temporary.write_bytes(payload)
        temporary.replace(destination)
    if close:plt.close(fig)



def figure1():
    """A vector concept illustration, a quantum circuit, and calculated data.

    The halo and wire arcs show mode geometry schematically. They are neither
    an accretion flow nor computed metric fluctuations or null geodesics.
    """
    from matplotlib.patches import Circle, Ellipse, Arc, FancyArrowPatch
    from matplotlib.colors import to_rgb
    from matplotlib.transforms import Bbox
    fig=plt.figure(figsize=(7.08,6.65))
    ax=fig.add_axes([.035,.633,.94,.327])
    ax.set(xlim=(0,12),ylim=(0,3.95));ax.set_aspect('equal');ax.axis('off')
    ax.text(.02,3.89,'a',weight='bold',fontsize=11,va='top')
    ax.text(.42,3.89,'Quantum fields, scattering and collected radiation',fontsize=9.2,va='top')
    def mix(color,white):
        return np.array(to_rgb(color))*(1-white)+white
    def arrow(p,q,col,rad=0,lw=1.15,scale=8):
        ax.add_patch(FancyArrowPatch(p,q,connectionstyle=f'arc3,rad={rad}',
                     arrowstyle='-|>',mutation_scale=scale,lw=lw,color=col,zorder=8))
    # Geometric vector illustration: the rim denotes the event horizon, not a
    # computed photon ring. The blue arcs are schematic field-mode guides.
    cx,cy,rad=1.97,1.94,1.0
    tt=np.linspace(0,2*np.pi,400)
    for j in range(48):
        rr=1.30-j*.0061
        ax.add_patch(Circle((cx,cy),rr,fc=mix('#ECAF57',.998-.17*j/47),ec='none',zorder=0))
    # Restrained field arcs leave the horizon and labels visually distinct.
    th=np.linspace(-.55,2.72,300)
    for j in range(3):
        rr=1.16+.12*j
        ax.plot(cx+rr*np.cos(th),cy+rr*np.sin(th),
                color=mix('#7297B5',.33+.17*j),lw=.62,zorder=1)
    for rr in [1.36,1.58]:
        xx=cx+rr*np.cos(tt);yy=cy+.31*rr*np.sin(tt)+.19*np.cos(tt)
        back=np.sin(tt)>0
        ax.plot(xx[back],yy[back],color='#BFCDD7',lw=.6,zorder=1)
    # Nested opaque vector disks give smooth, reproducible shading in EPS.
    for j in range(155):
        f=j/154
        ax.add_patch(Circle((cx-.20*f,cy+.20*f),rad*(1-.86*f),
            fc=np.array(to_rgb('#344B60'))*(1-f)+np.array(to_rgb('#030812'))*f,
            ec='none',zorder=3))
    ax.add_patch(Circle((cx,cy),rad,fill=False,ec='#DE9E4B',lw=1.25,zorder=5))
    # One front arc, rather than a dense set of disk-like ellipses.
    front=np.sin(tt)<0
    ax.plot((cx+1.58*np.cos(tt))[front],
            (cy+.31*1.58*np.sin(tt)+.19*np.cos(tt))[front],
            color='#A5BFCE',lw=.6,zorder=5)
    ax.text(cx-.09,cy+.06,'Black hole',color='white',ha='center',fontsize=8.5,zorder=7)
    ax.text(cx-.09,cy-.20,'fixed geometry',color='#C0CFDC',ha='center',fontsize=6.9,zorder=7)
    ax.plot([cx,cx],[.52,.85],color=GREY,lw=.6)
    ax.text(cx,.27,r'Event horizon  $r=2GM$',ha='center',fontsize=7.2)
    # The dotted connection is correlation only, not a causal outgoing ray.
    ax.plot([2.39,3.22],[2.44,2.10],':',color=C[3],lw=1.1,zorder=7)
    ax.scatter([2.39,3.22],[2.44,2.10],s=[12,12],c=['#E9BFD8',C[0]],zorder=9)
    ax.text(2.24,2.58,r'$C$',fontsize=8.5,color='#E9BFD8',zorder=8)
    ax.text(.10,3.20,'Partner sector',fontsize=7.2,color='#92567E')
    ax.plot([.84,1.42],[3.04,2.63],lw=.65,color='#AD7D9B')
    ax.text(3.25,2.74,'Mode\ncorrelations',ha='center',fontsize=6.6,color='#92567E')
    # The l=0 potential shape is schematic, with no shared spatial scale.
    xx=np.linspace(4.02,5.42,250);rr=2+(xx-4.02)*4.2
    vv=(1-2/rr)*2/rr**3;vv/=vv.max()
    ax.fill_between(xx,1.80,1.80+1.01*vv,color='#E6F2EE',zorder=0)
    ax.plot(xx,1.80+1.01*vv,color=C[2],lw=1.1,zorder=1)
    ax.text(4.70,3.23,'Curvature barrier',ha='center',fontsize=7.3,color='#007A5B')
    ax.text(4.70,3.00,r'$\Gamma_\ell(\omega)$',ha='center',fontsize=7.5,color='#007A5B')
    arrow((3.36,1.80),(4.37,1.80),C[0])
    ax.text(3.65,1.99,r'$a$',color=C[0],fontsize=8.5)
    arrow((4.45,1.80),(9.14,1.80),C[0],lw=.95)
    # This waveform depicts a mode function, not an expectation value of the
    # quantum field or a classical message. The envelope is illustrative.
    x=np.linspace(5.35,8.72,850)
    env=.31*np.exp(-((x-6.96)/.75)**2)
    wave=env*np.sin(18.7*(x-5.30))
    for lw,fade in [(5.3,.95),(3.4,.87),(1.9,.63)]:
        ax.plot(x,1.80+wave,color=mix(C[0],fade),lw=lw,zorder=2,solid_capstyle='round')
    ax.plot(x,1.80+wave,color=C[0],lw=1.05,zorder=3)
    for sign in [-1,1]:
        ax.plot(x,1.80+sign*env,color='#9EC5D9',lw=.6,ls=(0,(3,3)),zorder=2)
    ax.text(7.02,2.53,r'Outgoing radiation $R$',ha='center',color=C[0],fontsize=7.8)
    ax.text(7.02,2.31,'Coherence of the encoded field qubit',ha='center',
            color='#5B7183',fontsize=6.6)
    arrow((4.42,1.62),(3.28,.84),C[1],rad=-.45)
    ax.text(4.28,.54,r'Reflected sector $L$',ha='center',color=C[1],fontsize=7.3)
    arrow((7.26,3.25),(5.29,2.66),C[2],rad=.10,lw=.95)
    ax.text(7.45,3.38,r'Incoming vacuum $e$',ha='center',fontsize=7.2,color='#007A5B')
    # Mode selection precedes the decoder; R_g belongs to the selected output.
    ax.add_patch(Ellipse((9.20,1.80),.32,1.14,fc='#EFF6FA',ec='#A7C6D7',lw=.65,zorder=0))
    ax.add_patch(Arc((9.29,1.80),.68,1.45,theta1=105,theta2=255,lw=1.6,color=INK,zorder=7))
    ax.text(9.20,.88,'Select mode $g$',ha='center',fontsize=7.0)
    arrow((9.44,1.80),(10.12,1.80),INK,lw=1.0)
    ax.text(9.76,2.00,r'$R_g$',ha='center',fontsize=8.3,color=C[0])
    ax.add_patch(FancyBboxPatch((10.15,1.48),.62,.64,
        boxstyle='round,pad=.025,rounding_size=.07',fc='#EDF4FA',ec=C[0],lw=.9))
    ax.text(10.46,1.80,r'$\mathcal{D}$',ha='center',va='center',fontsize=12,color=C[0])
    ax.text(10.46,.88,'Decode',ha='center',fontsize=7.0)
    arrow((10.82,1.80),(11.24,1.80),INK,lw=1.0)
    # Wire-sphere output icon denotes a qubit, not a computed pure state.
    ax.add_patch(Circle((11.57,1.80),.28,fc='#F1F7FB',ec=C[0],lw=.75))
    ax.add_patch(Ellipse((11.57,1.80),.56,.19,fill=False,ec='#91B4CD',lw=.55))
    ax.add_patch(Ellipse((11.57,1.80),.20,.56,fill=False,ec='#91B4CD',lw=.55))
    ax.text(11.50,2.45,'Recovered\nqubit',ha='center',fontsize=7.0,color=C[0])
    # Exact subsystem layer: color identifies the physical operation;
    # muted branches identify systems inaccessible to the decoder.
    ax=fig.add_axes([.065,.382,.90,.211]);ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
    ax.text(-.028,1.06,'b',weight='bold',fontsize=11)
    ax.text(.025,1.06,'Reference-preserving recovery with quantum noise',fontsize=9.2)
    def box(x,y,w,h,label,col,fill='white',size=7.5):
        ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,
            boxstyle='round,pad=.006,rounding_size=.025',facecolor=fill,edgecolor=col,lw=.85))
        ax.text(x,y,label,ha='center',va='center',fontsize=size,color=col)
    def arr(x1,y1,x2,y2,col=INK,lw=.95):
        ax.annotate('',(x2,y2),(x1,y1),arrowprops=dict(arrowstyle='-|>',color=col,lw=lw))
    # One quiet background band groups all discarded outputs without suggesting
    # that they are classical noises or available recovery resources.
    ax.add_patch(FancyBboxPatch((.205,.785),.635,.14,
        boxstyle='round,pad=.012,rounding_size=.025',fc='#F3F5F8',ec='none'))
    box(.06,.46,.09,.23,r'$b$',C[0],'#EAF2FA',10)
    box(.06,.85,.09,.18,r'$Q$',C[0],'#EAF2FA',9)
    ax.plot([.052,.052],[.58,.75],color=C[0],lw=.75)
    ax.plot([.068,.068],[.58,.75],color=C[0],lw=.75)
    ax.text(.118,.81,'Isolated\nreference',fontsize=6.6,color='#4F6D82')
    box(.29,.46,.17,.29,'Quantum amplifier\n'+r'$\mathcal{G}$',C[1],'#FFF7EC',7.2)
    box(.535,.46,.16,.29,'Curvature filter\n'+r'$\Gamma$',C[2],'#EDF7F4',7.2)
    box(.785,.46,.12,.23,'Select mode\n'+r'$g$',C[0],'#EAF2FA',7.2)
    box(.955,.46,.065,.23,r'$\mathcal{D}$',C[0],'#EAF2FA',10)
    arr(.112,.46,.198,.46);arr(.382,.46,.448,.46)
    arr(.622,.46,.718,.46);arr(.852,.46,.916,.46)
    ax.text(.410,.57,r'$a$',ha='center',fontsize=8.3,color=C[0])
    ax.text(.670,.57,r'$R$',ha='center',fontsize=8.3,color=C[0])
    ax.text(.882,.57,r'$R_g$',ha='center',fontsize=8.3,color=C[0])
    for x,label in [(.29,'$C$ inaccessible'),(.535,'$L$ inaccessible'),(.785,'Other modes')]:
        arr(x,.625 if x<.7 else .59,x,.785,GREY,lw=.8)
        ax.text(x,.848,label,ha='center',va='center',fontsize=6.7,color='#586A80')
    for x,label in [(.29,'$c$ vacuum'),(.535,'$e$ vacuum')]:
        arr(x,.15,x,.30,GREY,lw=.8)
        ax.text(x,.065,label,ha='center',fontsize=6.8,color=GREY)
    ax.text(.06,.13,'Encoded\nfield qubit',ha='center',va='center',fontsize=6.8,color=C[0])
    ax.text(.875,.075,'Radiation-only recovery',ha='center',fontsize=6.6,color=C[0])
    # Standalone copy of precisely the two schematic panels, for author editing.
    # This is not an extra main-text figure. All elements remain vector in EPS.
    save(fig,'Schematic_Fig1ab',bbox=Bbox.from_extents(0,2.46,7.08,6.43),
         close=False,svg=True)
    # Lower panels are quantitative and use the same complete frames as all plots.
    gs=fig.add_gridspec(1,2,left=.105,right=.965,bottom=.075,top=.305,wspace=.39)
    ax=fig.add_subplot(gs[0,0]);panel(ax,'c','Same thermal output state')
    n=np.arange(7);N=.1;p=N**n/(1+N)**(n+1)
    ax.bar(n,p,color='#A9CEE1',edgecolor=C[0],width=.65,lw=.7)
    ax.set_yscale('log');ax.set(ylim=(1e-7,2),xticks=n,
        xlabel='Output occupation $n$',ylabel=r'$P(n\,|\,0)$')
    ax.text(.96,.94,'$N=0.1$\n'+r'Same state for every $\Gamma$',
            transform=ax.transAxes,ha='right',va='top',fontsize=7.2)
    ax=fig.add_subplot(gs[0,1]);panel(ax,'d','Different recoverability')
    d=data('equal_noise_recovery.csv')
    for N,col in zip([.03,.1,.5,1.],C):
        s=np.isclose(d['N'],N)
        ax.plot(d['Gamma'][s],d['F_lower'][s],color=col,label=f'$N={N:g}$')
    ax.axhline(.5,color=GREY,ls='--',lw=.9)
    ax.set(xlim=(0,1),ylim=(.25,1.01),xlabel=r'Barrier transmission $\Gamma$',
           ylabel=r'Optimal fidelity $F_\star$')
    legend(ax,loc='lower right',ncol=2,fontsize=6.8)
    ax.text(.025,.96,r'$\tau=N+\Gamma$',transform=ax.transAxes,va='top',fontsize=7.5)
    save(fig,'Fig1')


def supplementary_figure1():
    """Independent convergence evidence, deliberately kept outside the main results."""
    fig,axs=plt.subplots(2,2,figsize=(7.08,5.8))
    fig.subplots_adjust(left=.105,right=.97,bottom=.10,top=.94,wspace=.40,hspace=.48)
    rr=json.loads((ROOT/'validation'/'cutoff_convergence.json').read_text())
    D=np.array([r['dim'] for r in rr])
    lo=np.array([r['F_lower'] for r in rr]);hi=np.array([r['F_upper'] for r in rr])
    tail=np.array([r['cutoff_bound'] for r in rr])
    ax=axs[0,0];panel(ax,'a','Recovery bounds converge')
    ax.fill_between(D,lo,hi,color='#DCEAF4')
    ax.plot(D,hi,'o-',color=C[1],ms=3,label='Upper estimate')
    ax.plot(D,lo,'o-',color=C[0],ms=3,label='Feasible lower estimate')
    ax.set(xlabel='Fock dimension $D$',ylabel=r'Entanglement fidelity',xlim=(2,65),ylim=(.45,.62))
    legend(ax,loc='upper right',fontsize=7)
    ax.text(.97,.10,r'$\tau=1.2,\ N=1$',transform=ax.transAxes,ha='right',fontsize=8)
    ax=axs[0,1];panel(ax,'b','Tail control and numerical precision')
    ax.semilogy(D,hi-lo,'o-',color=C[0],ms=3,label='Full interval width')
    ax.semilogy(D,tail,'s--',color=C[1],ms=3,label='Analytic tail allowance')
    ax.set(xlabel='Fock dimension $D$',ylabel='Absolute fidelity scale',xlim=(2,65),ylim=(1e-19,1))
    legend(ax,loc='upper right',fontsize=7)
    ax=axs[1,0];panel(ax,'c','Independent scattering flux balance')
    r=data('radial_data.csv')
    for ell,col in enumerate(C[:3]):
        s=r['ell']==ell
        ax.semilogy(r['omega'][s],np.maximum(r['flux_error'][s],1e-16),
                    color=col,lw=1.1,label=f'$\\ell={ell}$')
    ax.set(xlabel=r'$GM\omega$',ylabel=r'$|1-\Gamma-\mathcal{R}|$',
           xlim=(0,.6),ylim=(1e-16,1e-9))
    legend(ax,loc='lower left',ncol=1,fontsize=7)
    ax=axs[1,1];panel(ax,'d','Packet results under grid refinement')
    rr=json.loads((ROOT/'validation'/'packet_refinement.json').read_text())
    for sigma,col in zip([.015,.035,.055],C):
        r=[v for v in rr if np.isclose(v['sigma'],sigma)]
        ax.semilogy([v['delay'] for v in r],[v['absolute_difference'] for v in r],
                    'o-',color=col,ms=2.5,label=f'$\\sigma={sigma:g}$')
    ax.set(xlabel=r'Receiver delay $\Delta t/(GM)$',
           ylabel=r'$|F_{\rm refined}-F_{\rm base}|$',xlim=(0,160),ylim=(1e-12,3e-8))
    legend(ax,loc='lower left',fontsize=7)
    save(fig,'FigS1')



def figure2():
    fig,axs=plt.subplots(2,2,figsize=(7.08,5.8))
    fig.subplots_adjust(left=.10,right=.955,bottom=.10,top=.94,wspace=.43,hspace=.48)
    d=data('recovery_frontier.csv');ts=np.unique(d['tau']);ns=np.unique(d['N'])
    f=np.full((len(ns),len(ts)),np.nan);neg=f.copy()
    for t,n,v,e in zip(d['tau'],d['N'],d['F_lower'],d['negativity']):
        i=np.searchsorted(ns,n);j=np.searchsorted(ts,t);f[i,j]=v;neg[i,j]=e
    cmap=LinearSegmentedColormap.from_list('recovery',['#F1F5FA','#BDD7E7','#3182BD','#08306B'])
    ax=axs[0,0];panel(ax,'a','All deterministic decoders')
    im=ax.pcolormesh(ts,ns,f,shading='nearest',cmap=cmap,vmin=.25,vmax=1,rasterized=True)
    ax.plot(ns,ns,color=C[1],ls='--',lw=1.4,label='$\\tau=N$')
    cs=ax.contour(ts,ns,f,levels=[.5,.75,.9],colors=INK,linewidths=.8)
    ax.clabel(cs,inline=True,fmt={.5:'0.50',.75:'0.75',.9:'0.90'},fontsize=7)
    ax.set(xlabel='Intensity response $\\tau$',ylabel='Vacuum occupation $N$',xlim=(0,1.8),ylim=(0,.8))
    ax.text(1.45,.12,'Not CP',ha='center',fontsize=8,color=GREY)
    cb=fig.colorbar(im,ax=ax,pad=.03,fraction=.047);cb.set_label('$F_\\star$',labelpad=3)
    ax=axs[0,1];panel(ax,'b','Entanglement survives earlier')
    for N,col in zip([0,.1,.5,.8],C):
        sel=np.isclose(d['N'],N)
        ax.plot(d['tau'][sel],d['negativity'][sel],color=col,label=f'$N={N:g}$')
        if N:ax.plot([N],[0],'o',color=col,ms=4)
    ax.set(xlabel='Intensity response $\\tau$',ylabel='Reference–output negativity',xlim=(0,1.8),ylim=(0,.52))
    legend(ax,loc='upper right',ncol=1)
    ax.text(.04,.94,'Entangled iff $\\tau>N$',transform=ax.transAxes,
            ha='left',va='top',fontsize=7.2)
    ax=axs[1,0];panel(ax,'c','Recovery and the classical bound')
    for N,col in zip([0,.1,.5,.8],C):
        sel=np.isclose(d['N'],N)
        ax.plot(d['tau'][sel],d['F_lower'][sel],color=col,label=f'$N={N:g}$')
    ax.axhline(.5,color=GREY,ls='--',lw=1)
    ax.set(xlabel='Intensity response $\\tau$',ylabel='$F_\\star$',xlim=(0,1.8),ylim=(.24,1.02))
    legend(ax,loc='lower right',ncol=2)
    ax=axs[1,1];panel(ax,'d','Benefit of optimizing the decoder')
    for N,col in zip([0,.1,.5,.8],C):
        sel=np.isclose(d['N'],N)
        gain=np.maximum(0,d['F_lower'][sel]-d['F_threshold'][sel])
        ax.plot(d['tau'][sel],gain,color=col,label=f'$N={N:g}$')
    ax.set(xlabel='Intensity response $\\tau$',ylabel='$F_\\star-F_{\\mathrm{th}}$',
           xlim=(0,1.8),ylim=(-.002,.067))
    legend(ax,loc='upper left',ncol=1,fontsize=7.2)
    ax.text(.97,.09,'Pure loss: the simple decoder is optimal',ha='right',
            transform=ax.transAxes,fontsize=7.4)
    save(fig,'Fig2')


def figure3():
    fig,axs=plt.subplots(2,2,figsize=(7.08,5.8))
    fig.subplots_adjust(left=.105,right=.97,bottom=.10,top=.94,wspace=.37,hspace=.46)
    d=data('schwarzschild_recovery.csv')
    with (ROOT/'data'/'frequency_thresholds.csv').open() as stream:
        thresholds={row['threshold']:float(row['omega'])
                    for row in csv.DictReader(stream) if int(row['ell'])==0}
    labels=['Scalar barrier transmission','Spontaneous Hawking occupation',
            'Optimal qubit recovery','Distinct operational thresholds']
    for ax,letter,title in zip(axs.flat,'abcd',labels):panel(ax,letter,title)
    for ell,col in enumerate(C[:3]):
        s=d['ell']==ell;w=d['omega'][s]
        axs[0,0].plot(w,d['Gamma'][s],color=col,label=f'$\\ell={ell}$')
        axs[0,1].semilogy(w,d['N'][s],color=col,label=f'$\\ell={ell}$')
        axs[1,0].plot(w,d['F_lower'][s],color=col,label=f'$\\ell={ell}$')
    axs[0,0].axhline(.5,ls='--',color=GREY,lw=1)
    axs[0,0].set(ylabel='$\\Gamma_\\ell$',ylim=(0,1.03))
    axs[0,1].set(ylabel='$N_\\ell=\\Gamma_\\ell n_{\\rm H}$',ylim=(1e-9,.05))
    axs[1,0].axhline(.5,ls='--',color=GREY,lw=1)
    axs[1,0].axhline(.9,ls=':',color=GREY,lw=1)
    axs[1,0].set(ylabel='$F_\\star$',ylim=(.24,1.02))
    for ax in [axs[0,0],axs[0,1],axs[1,0]]:
        ax.set(xlim=(0,.6),xlabel='$GM\\omega$');legend(ax,loc='best')
    ax=axs[1,1]
    s=d['ell']==0;w=d['omega'][s]
    ax.plot(w,d['F_lower'][s],color=C[0],label='$F_\\star$')
    ax.plot(w,d['Ic_nats'][s]/np.log(2),color=C[1],label='$I_c(n_s=1)$ [bits]')
    ax.axhline(0,color=GREY,lw=.7);ax.axhline(.5,color=GREY,lw=.7,ls='--')
    ax.axvspan(0,thresholds['Gamma_half'],color='#ECF1F5')
    ax.text(.03,-1.48,'$\\mathcal{Q}=0$',fontsize=8,color=GREY)
    ax.axvline(thresholds['F_half'],color=C[0],lw=.9,ls=':')
    ax.axvline(thresholds['Gamma_half'],color=GREY,lw=.9,ls='--')
    ax.axvline(thresholds['Ic_zero_ns1'],color=C[1],lw=.9,ls=':')
    ax.set(xlim=(.025,.22),ylim=(-1.65,1.5),xlabel='$GM\\omega$ ($\\ell=0$)',ylabel='Fidelity / coherent information')
    legend(ax,loc='upper left')
    save(fig,'Fig3')


def figure4():
    fig,axs=plt.subplots(2,2,figsize=(7.08,5.8))
    fig.subplots_adjust(left=.105,right=.90,bottom=.10,top=.94,wspace=.49,hspace=.46)
    d=data('packet_recovery.csv');spectra=data('packet_spectra.csv')
    titles=['Finite-band radiation packets','Phase mismatch at fixed noise',
            'Optimal deterministic recovery','Entanglement-breaking boundary']
    for ax,letter,title in zip(axs.flat,'abcd',titles):panel(ax,letter,title)
    for sigma,col in zip([.015,.035,.055],C):
        s=np.isclose(spectra['sigma'],sigma)
        axs[0,0].plot(spectra['omega'][s],spectra['input_density'][s],color=col,label=f'$\\sigma={sigma:g}$')
        s=np.isclose(d['sigma'],sigma)
        axs[0,1].semilogy(d['delay'][s],d['tau'][s],color=col)
        axs[0,1].plot(d['delay'][s],d['N'][s],color=col,ls='--',lw=1.1)
        axs[1,0].plot(d['delay'][s],d['F_lower'][s],color=col,label=f'$\\sigma={sigma:g}$')
    axs[0,0].set(xlabel='$w=GM\\omega$',ylabel='$|f_w(w)|^2$',xlim=(.005,.32),ylim=(0,29))
    legend(axs[0,0],loc='upper right')
    axs[0,1].set(xlabel='Receiver delay $\\Delta t/(GM)$',ylabel='Intensity response and noise',xlim=(0,120),ylim=(1e-5,1.2))
    axs[0,1].text(.04,.07,'Solid: $\\tau_{f g}$\nDashed: unchanged $N_g$',ha='left',va='bottom',
                    transform=axs[0,1].transAxes,fontsize=8)
    axs[1,0].axhline(.5,color=GREY,lw=1,ls='--')
    axs[1,0].set(xlabel='Receiver delay $\\Delta t/(GM)$',ylabel='$F_\\star$',xlim=(0,160),ylim=(.24,.91))
    legend(axs[1,0],loc='upper right')
    m=data('packet_access_map.csv');ds=np.unique(m['delay']);ss=np.unique(m['sigma'])
    z=m['log10_signal_noise'].reshape(len(ss),len(ds))
    cmap=LinearSegmentedColormap.from_list('access',['#CB7B4A','#FAF8F4','#347F9E'])
    im=axs[1,1].pcolormesh(ds,ss,z,cmap=cmap,norm=TwoSlopeNorm(vmin=-3,vcenter=0,vmax=2),
                           shading='nearest',rasterized=True)
    cs=axs[1,1].contour(ds,ss,z,levels=[0],colors=INK,linewidths=1.1)
    axs[1,1].clabel(cs,fmt={0:'$\\tau=N$'},fontsize=8)
    axs[1,1].set(xlabel='Receiver delay $\\Delta t/(GM)$',ylabel='Input bandwidth $\\sigma$',xlim=(0,160))
    axs[1,1].text(.04,.12,'Entanglement\nsurvives',transform=axs[1,1].transAxes,fontsize=8,color='white')
    axs[1,1].text(.95,.88,'Entanglement\nbreaking',transform=axs[1,1].transAxes,fontsize=8,ha='right')
    cb=fig.colorbar(im,ax=axs[1,1],pad=.03,fraction=.047)
    cb.set_label('$\\log_{10}(\\tau_{f g}/N_g)$',labelpad=3)
    save(fig,'Fig4')


if __name__=='__main__':
    for f in [figure1,figure2,figure3,figure4,supplementary_figure1]:f()
    print('Saved four main figures and one supplementary figure in EPS, PDF and PNG formats.')
